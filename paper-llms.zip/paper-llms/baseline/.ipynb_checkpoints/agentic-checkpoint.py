import openai
import json
import re
import subprocess
from utils import extract_code_from_string
import sys

def solve(problem_data, model_name='gpt-3.5-turbo'):
    problem_description = problem_data['description']
    code_example = problem_data['code_example']
    temperature = 0
    def get_extraction_response( problem_description, code_example):
        
        prompt =( r"""You will be given a verbal description of a stochastic programming problem such as two-stage stochastic problem (and its deterministic counterpart)  or chance constraint problems. Your task is to identify and extract the 
             following components from the text:
             Sets (e.g., time periods, locations, resources, scenarios, etc.)
             Parameters (e.g., costs, capacities, probabilities, demand values, etc.)
             Stochastic Variables (uncertain elements revealed in the second stage)
             Deterministic Decision Variables (first-stage decisions made before uncertainty is revealed)
             Present your answer in Python code using Gurobi. Below is also a code template. 
              New Problem Description:
            """ + f"{problem_description}\n\n" + f"{code_example}\n\n")
        


        messages = [
            {"role": "system", "content": "You are an expert in the extraction of elements from a stochastic optimization problem."},
            {"role": "user", "content": prompt}
        ]
        
        try:
            response = openai.ChatCompletion.create(
                model=model_name,
                messages=messages,
                temperature=temperature,
            )
            content = response.choices[0].message.content.strip()
            return content
        except Exception as e:
            return {"error": str(e)}
        
    def get_formulation_1_response(problem_description, code_example,  extraction_output):
        
        prompt = (
                    r""" You will be given a verbal description of a stochastic programming problem such as two-stage stochastic problem (and its deterministic counterpart)  or chance constraint problems, along with the extracted components 
                        including sets, parameters, 
                        stochastic variables, and deterministic decision variables.
                        Your task is to code the complete model in Python Gurobi. Specifically:
                        Clearly define the objective function.
                        Code all relevant constraints for different stages of the model.
                        Explicitly include the recourse function, indicating how second-stage decisions depend on the realization of uncertainty in mathematical terms if it is a two-stage stochastic problem.
                       """
                        "New Problem Description:\n"
                        f"{problem_description}\n\n"
                        "Below is the extraction output:\n"
                        f"{json.dumps(extraction_output, indent=2)}\n\n" 
                        "Below is the code template you should follow:\n"
                        f"{code_example}\n\n"
                )
            
        messages = [
                {"role": "system", "content": "You are an expert in coding stochastic models in Python Gurobi."},
                {"role": "user", "content": prompt}
            ]
        
        try:
            response = openai.ChatCompletion.create(
                model=model_name,
                messages=messages,
                temperature=temperature,
            )
            content = response.choices[0].message.content.strip()
            return content
        except Exception as e:
            return {"error": str(e)}
                
    def get_reviewers_feedback(problem_description, code_example, code):
        prompt = (
                        "You are a reviewer agent specialized in stochastic optimization problems. "
                        "You are provided with a problem description and a final Python code in Gurobi. "
                        "Review them carefully for potential mistakes (SUCH AS VARIABLES, OBJECTIVE FUNCTION, CONSTRAINTS OR PARAMETERS) and any additional elements that might be required. "
                        "Provide concise and precise feedback.\n\n"
                        "Problem Description:\n"
                        f"{problem_description}\n\n"
                        "Mathematical Formulation:\n"
                        f"{code}\n\n"
                        "Return your answer in valid JSON format with exactly the key feedback (string)." )
             
        feedbacks = []
        for i in range(4):
            
            
            messages = [
                    {"role": "system", "content": "You are a concise and precise reviewer agent. Only output valid JSON."},
                    {"role": "user", "content": prompt}
                   ]
            try:
                response =  openai.ChatCompletion.create(
                model=model_name,
                messages=messages,
                temperature=temperature
                            )
                content = response.choices[0].message.content.strip()
                feedback = content + f"{i}"
                feedbacks.append(feedback)
            except Exception as e:
                feedbacks.append({"error": str(e)})
        return feedbacks     
        
        
    def get_formulation_2_response(problem_description,code_example, old_code, reviewers_feedback):
        prompt = (
                    "You are an Updating Agent specialized in stochastic optimization "
                    "You are provided with the following information:\n\n"
                    "1. Problem Description:\n"
                    f"{problem_description}\n\n"
                    "2. Current Code:\n"
                    f"{old_code}\n\n"
                    "3. Feedback from Reviewer Agents:\n"
                    f"{json.dumps(reviewers_feedback, indent=2)}\n\n"
                    "Review the feedback carefully. If the feedback indicates valid improvements, update the code accordingly. "
                    "Return the updated final code. "
                    "Do not include any additional text."
                )
                
        messages = [
                    {"role": "system", "content": "You are a coding agent with Python Gurobi."},
                    {"role": "user", "content": prompt}
                ]
                
        try:
            response = openai.ChatCompletion.create(
                        model=model_name,
                        messages=messages,
                        temperature=temperature,
                    )
            content = response.choices[0].message.content.strip()
            return content
        except Exception as e:
            return {"error": str(e)}      
                        
        
    extraction_output = get_extraction_response( problem_description, code_example)
    formulation_output_1 =  get_formulation_1_response(problem_description,code_example, extraction_output)
    reviewers_output =  get_reviewers_feedback(problem_description,code_example, formulation_output_1)
    formulation_output_2 = get_formulation_2_response(problem_description,code_example, formulation_output_1, reviewers_output )
        
    return(formulation_output_2)
        
                
                      
        
        
        
        






            
