from langchain import PromptTemplate, OpenAI, LLMChain
from langchain.chat_models import ChatOpenAI

from utils import extract_code_from_string


def solve(problem_data, model_name='gpt-3.5-turbo'):
    problem_description = problem_data['description']
    code_example = problem_data['code_example']
    prompt_template =r"""
      "extract_elements": You will be given a verbal description of a two-stage stochastic linear programming (SLP-2) problem, or a deterministic two-stage problem, or chance constraint problem. Your task is to identify and extract the following components from the text:
     Sets (e.g., time periods, locations, resources, scenarios, etc.)
     Parameters (e.g., costs, capacities, probabilities, demand values, etc.)
     Stochastic Variables (uncertain elements revealed in the second stage)
     Deterministic Decision Variables (first-stage decisions made before uncertainty is revealed)
Present your answer in Python using Gurobi. 
 Now the original problem is as follows:
     {problem_description}
     Let's analyse the problem step by step.
     Here is a starter code:
     {code_example}
Please also learn the following instructions to guide you further: 
Here is a general form of a second-stage stochastic problem. 

    min_{{x}}cx + \mathrm{{E}}[h(x,\Tilde{{\xi}})] \label{{eqn:1}} 
    s.t. 
    Ax = b 
     x\geq 0, 
     \text{{where }} \quad h(x,\Tilde{{\xi}}) = \min_{{y}} \Tilde{{q}}^\top y
   s.t. \nonumber \\ 
     \Tilde{{D}}y = \Tilde{{B}}x + \Tilde{{d}} 
     y\geq 0 
Where 

    \Tilde{{D}}: Recourse matrix
    \Tilde{{B}}: Technology matrix
    \mathrm{{E}}[h(x,\Tilde{{\xi}})]: Recourse function 
Also, note that \Tilde{{q}}, \Tilde{{D}}, \Tilde{{B}} and \Tilde{{d}} are random variables and \Tilde{{\xi}} = (\Tilde{{q}}, \Tilde{{D}}, \Tilde{{B}},\Tilde{{d}}) is the vector representation of random variables, and \Tilde{{\xi}} takes values in its support or sample space, \Xi, i.e., a realization of $\Tilde{{\xi}}$ is \xi \in \Xi.
If it is a two stage deterministic problem, its structure is similar to two stage stochastic problem except that everythin is deterministic. 
If it is a chance constraint model, use the following instructions: 
Chance-constrained models are optimization models that incorporate uncertainty by allowing certain constraints to be violated with a probability. Instead of requiring that a constraint always be satisfied (which can be conservative when dealing with uncertain data), a chance-constrained model wants constraint(s) to be satisfied most of the time, with some confidence. In particular, the joint chance constraint model seeks to minimize the cost while ensuring that all constraints are satisfied simultaneously with at least probability \( \alpha \):
\begin{{alignat*}}{{2}}
    &\min_{{x }}\quad  &&c^\top x\\ 
    &\text{{s.t.}} &&\mathbb{{P}}( \Tilde{{A}}x \leq \Tilde{{b}}) \geq  \alpha \\ 
    &  &&x\geq 0 
\end{{alignat*}}
where:
\begin{{itemize}}
  \item \( x \in \mathbb{{R}}^n_+ \): decision variables
  \item \( \alpha \in [0,1] \): acceptable joint violation probability level
  \item \( \mathbb{{P}}(\cdot) \): probability measure
\end{{itemize}}
Individual chance constraints ensure that each constraint is satisfied with some probability, individually, rather than requiring that all constraints hold simultaneously:
\begin{{alignat*}}{{2}}
    &\min_{{x}} \quad && c^\top x \\ 
    &\text{{s.t.}} &&\mathbb{{P}}\left( \Tilde{{A}}_i x \leq \Tilde{{b}}_i \right) \geq \alpha_i, \quad \forall i = 1, \dots, m
\end{{alignat*}}
    "formulate_model": Now, given the sets, variables, parameters and objective function from previous step, 
Your task is to formulate the complete the model. Specifically:
 Clearly define the objective function, including the first-stage costs and the expected recourse (second-stage) costs.
 Write all relevant constraints for both stages of the model.
 Explicitly include the recourse function, indicating how second-stage decisions depend on the realization of uncertainty.
Make sure that you are doing this in Python using Gurobi.  Now the original problem is as follows:
     {problem_description}
     Let's analyse the problem step by step.
     Here is a starter code:
     {code_example}
Only if it is a two stage stochastic model: 
    "extensive_form": Now,
Your task is to construct the extensive form of this SLP-2 model. Specifically:
 Enumerate all possible scenarios, associating each with its corresponding probability.
 Replace the expected value term in the objective function with scenario-specific expressions to form a deterministic equivalent.
 Replicate and customize the second-stage constraints and variables for each scenario.
Present the full model in a single-stage linear programming format suitable for direct input into an LP solver.
Clearly label all variables and constraints by scenario.
Please also see the instruction below for further guidance: 
Now, if |\Xi| = s, the extensive deterministic form of the problem in previous instructions is as follows: 
\begin{{align}}
    \min_{{x, \mathbf{{y}}}} \quad  cx + \sum_{{i=1}}^s  p^i q^{{i\top}} y^i \nonumber\\
    & s.t. \nonumber\\ 
    & Ax = b \nonumber\\ 
    & - B^1 x + D^1 y^1 =   d^1\nonumber \\ 
    &\vdots \\ 
    & - B^s x + D^s y^s =   d^s\nonumber \\
    & x, \mathbf{{y}} \geq 0 \nonumber
\end{{align}}
    "python_code": Now, you are provided with the complete mathematical formulation of the stochastic problem or two stage deterministic problem.

     Your task is to generate  the complete Python code using the Gurobi solver. 

     Now the original problem is as follows:
     {problem_description}
     Let's analyse the problem step by step, then give your final Python code.
     Here is a starter code:
     {code_example}
     """
    
    

    llm = ChatOpenAI(
        model_name=model_name,
        temperature=0
    )
    llm_chain = LLMChain(
        llm=llm,
        prompt=PromptTemplate.from_template(prompt_template)
    )
    answer = llm_chain.predict(problem_description=problem_description, code_example=code_example)
    return answer