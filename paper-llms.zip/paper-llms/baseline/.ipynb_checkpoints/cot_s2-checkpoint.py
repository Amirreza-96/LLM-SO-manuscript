from langchain import PromptTemplate, OpenAI, LLMChain
from langchain.chat_models import ChatOpenAI

from utils import extract_code_from_string


def solve(problem_data, model_name='gpt-3.5-turbo'):
    problem_description = problem_data['description']
    code_example = problem_data['code_example']
    prompt_template = """ extract_elements: You are an expert in Gurobi and stochastic optimization. You will be given a verbal description of a stochastic optimization problem. 
     It is either a two-stage stochastic problem, its deterministic two-stage counterpart or a chance constraint optimization problem. Your task is to identify and extract the 
     following components from the text:
     Sets (e.g., time periods, locations, resources, scenarios, etc.)
     Parameters (e.g., costs, capacities, probabilities, demand values, etc.)
     Stochastic Variables (uncertain elements revealed in the second stage)
     Deterministic Decision Variables (first-stage decisions made before uncertainty is revealed)
     Present your Python code for the elements above. Here is a code template {code_example}. Your extraction will serve as the foundation for subsequent code implementation.

     
     formulate_model: Now, you are provided with the extracted components, including sets, parameters, stochastic variables, and deterministic decision variables.
     Your task is to formulate the complete model in Python Gurobi. Specifically:
     Clearly define the objective function, including the first-stage costs and the expected recourse (second-stage) costs.
     Write all relevant constraints for both stages of the model.
     Explicitly include the recourse function, indicating how second-stage decisions depend on the realization of uncertainty.

    
    
     extensive_form: Now, you are given the Python Gurobi formulation of the problem (including sets, parameters, decision variables, objective function, and constraints).

     Your task is to construct the extensive form of this problem in Python using Gurobi by modifying the previous code. Specifically:


     Enumerate all possible scenarios, associating each with its corresponding probability.
     Replace the expected value term in the objective function with scenario-specific expressions to form a deterministic equivalent if it is a two-stage stochastic problem.
     Replicate and customize the second-stage constraints and variables for each scenario if it is a two-stage stochastic problem.
     Present the full model in a single-stage linear programming format suitable for direct input into a Gurobi solver in Python. Note the code example. 

     Now the original problem is as follows:
     {problem_description}
     Let's analyse the problem step by step, then give your final Python code.
     Here is a starter code:
     {code_example}"""

    llm = ChatOpenAI(
        model_name=model_name,
        temperature=0
    )
    llm_chain = LLMChain(
        llm=llm,
        prompt=PromptTemplate.from_template(prompt_template)
    )
    answer = llm_chain.predict(problem_description=problem_description, code_example=code_example)
    return answer