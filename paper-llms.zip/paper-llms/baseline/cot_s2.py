from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_openai import ChatOpenAI

from utils import extract_code_from_string


def solve(problem_data, model_name='gpt-4o-mini'):
    problem_description = problem_data['description']
    code_example = problem_data['code_example']

    prompt_template = """extract_elements: You are an expert in Gurobi and Stochastic Optimization (SO). You will be given a verbal description of an SO problem. 
     It is either a two-stage stochastic mixed-integer linear programming (SMILP-2), its two-stage deterministic mixed-integer linear programming (DMILP-2) counterpart, or an individual or joint chance-constrained optimization problem. Your task is to identify and extract the 
     following:
      - Sets and indices (e.g., time periods, locations, resources, scenarios, etc.)
    - Deterministic and stochastic parameters (e.g., costs, capacities, probabilities, uncertain demand values, etc.)
    - Variables (e.g., first- and second- stage decisions in an SMILP-2 problem, integer variables, etc.)
     Present your Python code for the elements above. Here is a code template: {code_example}. Your extraction will serve as the foundation for subsequent code implementation.
     formulate_model: Now, you are provided with the extracted components, including sets and indices, deterministic or stochastic parameters, and variables.
     Your task is to formulate the complete model in Python Gurobi. Specifically:
     Clearly define the objective function, including the first-stage costs and the expected recourse (second-stage) costs for SMILP-2 and DMILP-2 problems.
     Write all relevant constraints of the model. Use scenario-based indicator reformulations by integer variables and big-M to linearize chance constraints.
     extensive_form: Now, you are given the Python Gurobi formulation of the problem (including sets, indices, parameters, decision variables, objective function, and constraints).
     If it is an SMILP-2 or DMILP-2 problem, your task is to construct the extensive form of this problem in Python using Gurobi by modifying the previous code. Specifically:
     Enumerate all possible scenarios, associating each with its corresponding probability.
     Replace the expected value term in the objective function with scenario-specific expressions to form a deterministic equivalent if it is an SMILP-2 problem by replicating and customizing the second-stage constraints and variables for each scenario.
     Present the full model in a single-stage linear programming format suitable for direct input into a Gurobi solver in Python. Note the code example. 
     Now the original problem is as follows:
     {problem_description}.
     Let's analyse the problem step by step, then give your final Python code.
     Here is a starter code:
     {code_example}.
"""

   
    prompt = PromptTemplate.from_template(prompt_template)

   
    llm = ChatOpenAI(
        model=model_name,
        temperature=0,
    )

   
    parser = StrOutputParser()

   
    chain = prompt | llm | parser

    
    answer = chain.invoke(
        {
            "problem_description": problem_description,
            "code_example": code_example,
        }
    )

    return answer
