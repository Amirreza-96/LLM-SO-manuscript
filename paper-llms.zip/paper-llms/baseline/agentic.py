from openai import OpenAI
import json
import re
import subprocess
from utils import extract_code_from_string
import sys

import os
os.environ["OPENAI_API_KEY"] = "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"
client = OpenAI()  


def solve(problem_data, model_name='gpt-4o-mini'):
    problem_description = problem_data['description']
    code_example = problem_data['code_example']
    temperature = 0

    def chat_once(prompt, system_msg, model_name, temperature):
       
        response = client.chat.completions.create(
            model=model_name,
            temperature=temperature,
            messages=[
                {"role": "system", "content": system_msg},
                {"role": "user", "content": prompt},
            ],
        )
        return response.choices[0].message.content.strip()

    def get_extraction_response(problem_description, code_example):
        prompt = (
            r"""You will be given a verbal description of a Stochastic Optimization problem, such as a two-stage stochastic mixed-integer linear programming (SMILP-2) problem (or its two-stage deterministic mixed-integer linear programming counterpart)  or individual and joint chance-constrained problems. Your task is to identify and extract the 
             following components from the text:
              - Sets and indices (e.g., time periods, locations, resources, scenarios, etc.)
             - Deterministic and stochastic parameters (e.g., costs, capacities, probabilities, uncertain demand values, etc.)
             - Variables (e.g., first- and second- stage decisions in an SMILP-2 problem, integer variables, etc.)
             Present your answer in Python code using Gurobi. Below is also a code template, and 
              problem description:
"""
            + f"{problem_description}\n\n"
            + f"{code_example}\n\n"
        )

        system_msg = (
            "You are an expert in the extraction of elements from a stochastic optimization problem."
        )

        try:
            content = chat_once(
                prompt=prompt,
                system_msg=system_msg,
                model_name=model_name,
                temperature=temperature,
            )
            return content
        except Exception as e:
            return {"error": str(e)}

    def get_formulation_1_response(problem_description, code_example, extraction_output):
        prompt = (
            r"""You will be given a verbal description of a Stochastic Optimization problem, such as a two-stage stochastic mixed-integer linear programming (SMILP-2) problem (or its two-stage deterministic mixed-integer programming counterpart), individual or joint chance-constrained problems, along with the extracted components 
                        including sets, indices, stochastic and deterministic parameters, 
                        and variables.
                        Your task is to code the complete model in Python using Gurobi. Specifically:
                        Clearly define the objective function.
                        Code all relevant constraints. Specifically, if it is an SMILP-2 problem, you need to code the extensive form of the problem. Use scenario-based indicator reformulations by integer variables and big-M to linearize chance constraints.
                      
"""
            + f"{problem_description}\n\n"
            + "Below is the extraction output:\n"
            + f"{json.dumps(extraction_output, indent=2)}\n\n"
            + "Below is the code template you should follow:\n"
            + f"{code_example}\n\n"
        )

        system_msg = "You are an expert in coding stochastic models in Python Gurobi."

        try:
            content = chat_once(
                prompt=prompt,
                system_msg=system_msg,
                model_name=model_name,
                temperature=temperature,
            )
            return content
        except Exception as e:
            return {"error": str(e)}

    def get_reviewers_feedback(problem_description, code_example, code):
        prompt = (
            """ You are a reviewer agent specialized in Stochastic Optimization problems. 
                        You are provided with a problem description and a final Python code using Gurobi solver. 
                        Review them carefully for potential mistakes (such as variables, objective function, constraints, parameters, and syntax errors) and any additional elements that might be required. 
                        Provide concise and precise feedback.
        """
            "Problem Description:\n"
            f"{problem_description}\n\n"
            "Mathematical Formulation:\n"
            f"{code}\n\n"
        )

        system_msg = (
            "You are a concise and precise reviewer agent. Only output valid JSON."
        )

        feedbacks = []
        for i in range(4):
            try:
                content = chat_once(
                    prompt=prompt,
                    system_msg=system_msg,
                    model_name=model_name,
                    temperature=temperature,
                )
                
                feedback = content + f"{i}"
                feedbacks.append(feedback)
            except Exception as e:
                feedbacks.append({"error": str(e)})
        return feedbacks

    def get_formulation_2_response(problem_description, code_example, old_code, reviewers_feedback):
        prompt = (           
            "You are a specialized updating agent in Stochastic Optimization.\n\n"
            "You are provided with the following information:\n\n"
            "1. Problem Description:\n"
            f"{problem_description}\n\n"
            "2. Current Code:\n"
            f"{old_code}\n\n"
            "3. Feedback from Reviewer Agents:\n"
            f"{json.dumps(reviewers_feedback, indent=2)}\n\n"
            "Review the feedback carefully. If the feedback indicates valid improvements, update the code accordingly. "
            "Return the updated final code. "
            "Do not include any additional text."
        )

        system_msg = "You are a coding agent with Python Gurobi."

        try:
            content = chat_once(
                prompt=prompt,
                system_msg=system_msg,
                model_name=model_name,
                temperature=temperature,
            )
            return content
        except Exception as e:
            return {"error": str(e)}

   
    extraction_output = get_extraction_response(problem_description, code_example)
    formulation_output_1 = get_formulation_1_response(
        problem_description,
        code_example,
        extraction_output,
    )
    reviewers_output = get_reviewers_feedback(
        problem_description,
        code_example,
        formulation_output_1,
    )
    formulation_output_2 = get_formulation_2_response(
        problem_description,
        code_example,
        formulation_output_1,
        reviewers_output,
    )

    return formulation_output_2
