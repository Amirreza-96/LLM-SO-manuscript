from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_openai import ChatOpenAI

from utils import extract_code_from_string


def solve(problem_data, model_name='gpt-4o-mini'):
    problem_description = problem_data['description']
    code_example = problem_data['code_example']

    prompt_template = """You are a Python programmer in the field of Operations Research and Stochastic Optimization. Your proficiency in utilizing third-party libraries such as Gurobi is essential. In addition to your expertise in Gurobi, it would be great if you could also provide some background in related libraries or tools, like NumPy and SciPy.
You are given a specific problem. You aim to develop an efficient Python program that addresses the given problem.
Now the original problem is as follows: problem_description. Here is a starter code:
code_example. Give your Python code directly.
"""

    
    prompt = PromptTemplate.from_template(prompt_template)

    
    llm = ChatOpenAI(
        model=model_name,
        temperature=0,
    )

  
    parser = StrOutputParser()

  
    chain = prompt | llm | parser

  
    raw_answer = chain.invoke(
        {
            "problem_description": problem_description,
            "code_example": code_example,
        }
    )

   
    code = extract_code_from_string(raw_answer)

    return code
