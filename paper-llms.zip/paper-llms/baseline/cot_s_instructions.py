from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_openai import ChatOpenAI

from utils import extract_code_from_string


def solve(problem_data, model_name='gpt-4o-mini'):
    problem_description = problem_data['description']
    code_example = problem_data['code_example']

    prompt_template = r"""
extract_elements: You will be given a verbal description of a two-stage stochastic mixed-integer linear programming (SMILP-2) problem, or a two-stage deterministic mixed-integer linear programming (DMILP-2) problem, or an individual or joint chance-constrained problem. Your task is to identify and extract the following components from the text:
 - Sets and indices (e.g., time periods, locations, resources, scenarios, etc.)
- Deterministic and stochastic parameters (e.g., costs, capacities, probabilities, uncertain demand values, etc.)
- Variables (e.g., first- and second- stage decisions in an SMILP-2 problem, integer variables, etc.)
Present your answer in Python using Gurobi. 

The original problem is as follows:
{{ problem_description }}.

Let's analyse the problem step by step.
Here is a starter code:
{{ code_example }}.

Learn the following instructions to guide you further if it is an SMILP-2:


Throughout this prompt, the $i^{th}$ row of a matrix $A$ is denoted by $A_{i\cdot}$, and the $i^{th}$ element of a vector $x$ is denoted by $x_i$. 
Let $(\tilde{A}, \tilde{b})\in \mathbb{R}^{m\times n}\times \mathbb{R}^{m}$ denote random elements defined on a probability space $(\Xi,\mathcal{F},\mathbb{P})$ where $\Xi$ is the set of all possible realizations of the stochastic parameters, $\mathcal{F}$ is a $\sigma$-algebra of measurable events on $\Xi$, and $\mathbb{P}$ is a probability measure on $(\Xi,\mathcal{F})$.  The simplest SMILP-2 model generalizes the DMILP-2 formulation by allowing the second-stage data to be random. A scenario $\xi \in \Xi$ specifies a complete realization of the random second-stage problem data. We denote this data by the random vector $\Tilde{\xi} = \texttt{vec}(\Tilde{q}, \Tilde{D}, \Tilde{B}, \Tilde{d})$, where $\xi \in \Xi$ is a realization of $\Tilde{\xi}$,  $\Tilde{q}$ is a random cost vector for the recourse decision, $\Tilde{D}$ is a random constraint matrix for the recourse system, $\Tilde{B}$ is a random matrix that couples the first-stage decision to the second-stage system, and $\Tilde{d}$ is a random right-hand side vector with dimensions defined for their deterministic counterpart above. 
Given this setup, the SMILP-2 is
\begin{alignat}{2}
    \min_{x \in \mathcal{X}} \quad 
        & c^\top x + \mathbb{E}\!\left[h(x,\Tilde{\xi})\right] \label{eq:slp2} \\
    \text{s.t.} \quad 
        & A x = b, \nonumber 
\end{alignat}
where  $h(x,\Tilde{\xi}) := \min\limits_{y \in \mathcal{Y}}\{\Tilde{q}^\top y | \Tilde{D} y = \Tilde{B} x + \Tilde{d}\}.$ 
We assume relatively complete recourse and the $h(x,\tilde\xi)$ is integrable for all $x\in\mathcal{X}$.

The expectation $\mathbb{E}[h(x,\Tilde{\xi})]$ in~\eqref{eq:slp2} is taken with respect to the probability measure $\mathbb{P}$ on $(\Xi,\mathcal{F})$, i.e., $\mathbb{E}[h(x,\tilde\xi)] = \int_{\xi\in \Xi} h(x,\Tilde{\xi}))  \mathrm{d}\mathbb{P}(\xi),$ and represents the expected optimal recourse cost associated with $x$. 



If it is a chance-constraint model, use the following instructions: 


Chance-constrained models provides a probabilistic framework for decision‐making under uncertainty by allowing controlled constraint violations. 
A joint chance-constrained program requires that all constraints hold simultaneously with probability at least~$1-\alpha$:
\begin{alignat*}{2}
    \min_{x \in \mathcal{X}} \quad & c^\top x \\
    \text{s.t.} \quad 
    & \mathbb{P}\big( \tilde{A}x \le \tilde{b} \big) \;\ge\; 1-\alpha,
\end{alignat*}
where $c\in \mathbb{R}^{n}$ is a cost vector, vector $x\in \mathcal{X}\subseteq \mathbb{Z}_{+}^k \times \mathbb{R}^{n-k}_{+}$ contains non-negative decision variables (with first $k$ variables being integer) and $\alpha \in [0,1]$ is the prescribed confidence level.  
Equivalently, the probability that any constraint is violated is limited by a risk budget:
\[
\mathbb{P}\big( \exists i:\, (\tilde{A}_{i\cdot} x > \tilde{b}_i) \big) \;\le\;  \alpha.
\]
 In this paper, we assume the probability law $\mathbb{P}$ is approximated by a finite empirical distribution supported on a finite set of sample scenarios . Thus, one can replace the chance constraints with finite-scenario approximations by sample-average approximation techniques, which can be formulated linearly using integer variables (e.g., see \cite{luedtke2008sample}, \cite[p. 351]{prekopa2013stochastic}).  

By contrast, an individual chance-constrained formulation enforces probabilistic feasibility separately for each constraint:
\begin{alignat*}{2}
    \min_{x \in \mathcal{X}} \quad & c^\top x \\
    \text{s.t.} \quad 
    & \mathbb{P}\big( \tilde{A}_{i\cdot} x \le \tilde{b}_i \big) \;\ge\; 1- \alpha_i, 
    \qquad i = 1,\dots,m,
\end{alignat*}
where the confidence level $\alpha_i$ may vary across constraints to represent heterogeneous reliability or safety requirements \cite{prekopa2013stochastic}.  
While the joint model enforces global reliability, the individual model allows constraint-wise flexibility at the expense of potentially weaker overall guarantees.  

The distinction between joint and individual chance-constrained formulations is central to understanding how language models interpret and encode probabilistic logic, specifically, whether they recognize collective feasibility events or treat constraints independently in mathematical syntax.



If it is a DMILP-2 model, use the following instructions: 

A two-stage deterministic mixed-integer linear programming (DMILP-2) formulation is a linear recourse model without uncertainty.  
First-stage variables $x$ are chosen initially; second-stage variables $y\in \mathcal{Y}\subseteq \mathbb{Z}_{+}^{p}\times \mathbb{R}^{r-p}_{+}$ adjust subsequently without uncertainty, and given $D \in \mathbb{R}^{z\times r}, B\in \mathbb{R}^{z\times n}, q\in \mathbb{R}^r$ and $d\in \mathbb{R}^{z}$, DMILP-2 is formulated as follows: 
\begin{alignat*}{2}
    \min_{x \in \mathcal{X}} \quad & c^\top x + h(x)\nonumber \\
    \text{s.t.} \quad & A x = b,
\end{alignat*}
where $h(x):=\min\limits_{y\in \mathcal{Y}}\{ q^\top y | D y = Bx + d\}$, represents the optimal cost of the second-stage response for a given first-stage decision $x$.  
This deterministic formulation serves as a baseline for comparing how LLMs can recover a hierarchical decision structure with random parameters when facing SMILP-2 problems.


formulate_model: Now, given the sets, indices, variables, and stochastic and deterministic parameters from the previous step,
Your task is to formulate the complete model. Specifically:
- Clearly define the objective function, including the first-stage objective and the expected recourse (second-stage) objective if it is an SMILP-2 problem.
- Code all constraints. Use scenario-based indicator reformulations by integer variables and big-M to linearize chance constraints.
extensive_form (only if it is an SMILP-2 problem): Now,
Your task is to construct the extensive form of this SMILP-2 model. Specifically:
- Enumerate all possible scenarios, associating each with its corresponding probability.
- Replace the expected value term in the objective function with scenario-specific expressions to form a deterministic equivalent by replicating and customizing the second-stage constraints and variables for each scenario.
- Present the full model in a single-stage linear programming format suitable for direct input into an LP solver.
Clearly label all variables and constraints by scenario.

Read the instructions below for further guidance on the extensive counterpart of an SMILP-2: 

In many practical settings, the uncertainty set $\Xi$ is modeled as a finite scenario set $\{\xi^1,\ldots,\xi^{s}\}$ with strictly positive scenario probabilities $p^1,\ldots,p^{s}$ satisfying $\sum_{i=1}^{s} p^i = 1$. In that case, each scenario $\xi^i$ induces deterministic data $\texttt{vec}(q^{i}, D^{i}, B^{i},d^{i})$, and the expectation operator in~\eqref{eq:slp2} reduces to a finite weighted sum. The equivalent extensive-form deterministic model is then given by
\begin{alignat*}{2}
    \min_{x\in \mathcal{X},\;y^i\in \mathcal{Y} (i=1,\dots, s)}& 
        && c^\top x + \sum_{i=1}^{s} p^{i} \,(q^{i})^\top y^{i} \\
    \text{s.t.}\ \qquad & 
        && A x = b, \\
      &  && D^{i} y^{i} = B^{i} x + d^{i}, \quad i = 1,\dots,s. 
\end{alignat*}
In this deterministic equivalent, the variable $y^{i}$ represents the recourse action that would be taken if scenario $\xi^{i}$ materializes. The linear system $D^{i} y^{i} = B^{i} x + d^{i}$ enforces scenario-wise feasibility, and the weighted sum $\sum_{i=1}^{s} p^{i} (q^{i})^\top y^{i}$ captures the expected recourse cost under the scenario probabilities.


python_code: Now, you are provided with the complete mathematical formulation of the SO problem or DMILP-2 problem.

Your task is to generate the complete Python code using Gurobi solver. 

"""

    # IMPORTANT: use jinja2 to avoid brace conflicts with LaTeX/math in the prompt
    prompt = PromptTemplate(
        template=prompt_template,
        template_format="jinja2",
        input_variables=["problem_description", "code_example"],
    )

    llm = ChatOpenAI(
        model=model_name,
        temperature=0,
    )

    parser = StrOutputParser()

    chain = prompt | llm | parser

    answer = chain.invoke(
        {
            "problem_description": problem_description,
            "code_example": code_example,
        }
    )

    return answer
