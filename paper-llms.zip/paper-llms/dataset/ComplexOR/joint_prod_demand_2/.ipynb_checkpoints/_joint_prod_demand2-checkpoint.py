from gurobipy import Model, GRB, quicksum

def solve_joint_chance_from_input(input_data):
    alpha = input_data["alpha"]
    demand_samples = input_data["demand_samples"]
    num_scenarios = input_data["num_scenarios"]

    model = Model("JointChanceConstraint")
    model.setParam("OutputFlag", 0)

    # Decision variables
    x = model.addVars(2, lb=0, name="x")  # x[0]: market 1, x[1]: market 2

    # Binary indicators for violations
    z = model.addVars(num_scenarios, vtype=GRB.BINARY, name="z")

    M = 1e4  # Big-M constant

    for s in range(num_scenarios):
        d1, d2 = demand_samples[s]
        model.addConstr(x[0] >= d1 - M * z[s])
        model.addConstr(x[1] >= d2 - M * z[s])

    model.addConstr(quicksum(z[s] for s in range(num_scenarios)) <= int(alpha * num_scenarios))

    model.setObjective(x[0] + x[1], GRB.MINIMIZE)
    model.optimize()

    if model.Status == GRB.OPTIMAL:
        x_val = model.getAttr("x", x)
        return {
            "x1": round(x_val[0], 2),
            "x2": round(x_val[1], 2),
            "objective": round(model.ObjVal, 2)
        }
    else:
        return None
