def individual_chance_storage_planning(input_data):
    """
    Args:
        input_data: dict with keys:
            - 'alpha': float, allowed violation probability per facility (e.g., 0.05)
            - 'demand_samples': list of lists, each [east_demand, west_demand] per scenario

    Returns:
        min_total_capacity: float, total capacity installed across both facilities
    """
    min_total_capacity = 0  # Placeholder
    return min_total_capacity