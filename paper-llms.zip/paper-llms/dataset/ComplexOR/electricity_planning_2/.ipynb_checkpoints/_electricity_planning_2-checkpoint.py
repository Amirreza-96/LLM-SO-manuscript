from gurobipy import Model, GRB, quicksum

def solve_electricity_planning(
    c,                # List[float], capacity installation cost per terminal (length |P|)
    a,                # List[List[float]], resource use: a[i][k] = usage of resource k per unit capacity at terminal i (shape |P| x |R|)
    r,                # List[float], available amount of each resource (length |R|)
    p,                # List[List[float]], transport or production cost from terminal i to location j (shape |P| x |C|)
    revenue,          # List[float], revenue per unit demand fulfilled at each customer j (length |C|)
    demand_scenarios  # List[Tuple[float, List[float]]], each tuple is (probability, demand vector for each j ∈ C)
):
    P = range(len(c))         # Terminals
    R = range(len(r))         # Resource types
    C = range(len(p[0]))      # Demand locations
    S = range(len(demand_scenarios))  # Scenario indices

    # Create model
    model = Model("ElectricityPlanning_ProfitMax")
    model.setParam("OutputFlag", 0)

    # --- First-stage decision variables ---
    x = model.addVars(P, name="x", lb=0)

    # --- Second-stage decision variables ---
    y = model.addVars(P, C, S, name="y", lb=0)

    # --- Resource constraints ---
    for k in R:
        model.addConstr(
            quicksum(a[i][k] * x[i] for i in P) <= r[k],
            name=f"resource_{k}"
        )

    # --- Second-stage constraints per scenario ---
    for s in S:
        prob, demand = demand_scenarios[s]

        # Terminal capacity constraint
        for i in P:
            model.addConstr(
                quicksum(y[i, j, s] for j in C) <= x[i],
                name=f"capacity_s{s}_i{i}"
            )

        # Demand cannot be exceeded
        for j in C:
            model.addConstr(
                quicksum(y[i, j, s] for i in P) <= demand[j],
                name=f"demand_s{s}_j{j}"
            )

    # --- Objective: Maximize expected profit ---
    expected_revenue = quicksum(
        demand_scenarios[s][0] * revenue[j] * y[i, j, s]
        for s in S for i in P for j in C
    )
    install_cost = quicksum(c[i] * x[i] for i in P)
    expected_cost = quicksum(
        demand_scenarios[s][0] * p[i][j] * y[i, j, s]
        for s in S for i in P for j in C
    )

    model.setObjective(expected_revenue - install_cost - expected_cost, GRB.MAXIMIZE)

    model.optimize()

    if model.Status == GRB.OPTIMAL:
        return model.ObjVal
    else:
        return None
