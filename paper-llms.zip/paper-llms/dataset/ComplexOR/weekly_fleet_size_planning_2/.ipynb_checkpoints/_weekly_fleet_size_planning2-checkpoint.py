from gurobipy import Model, GRB, quicksum

def weekly_fleet_sizing(vehicle_costs, max_vehicles, move_costs_loaded, move_costs_empty,
                        penalties, demand_scenarios):
    """
    Solves the weekly fleet sizing problem using Gurobi.

    Args:
        vehicle_costs: 2D list |L|x|K|, cost of deploying vehicles of each type at each terminal
        max_vehicles: list of length |K|, maximum vehicles available of each type
        move_costs_loaded: 3D list |L|x|L|x|K|, loaded movement cost between terminals per vehicle type
        move_costs_empty: 3D list |L|x|L|x|K|, empty movement cost between terminals per vehicle type
        penalties: 2D list |L|x|K|, penalty per imbalance at each terminal for each vehicle type
        demand_scenarios: list of tuples (probability, 3D demand matrix [i][j][k])

    Returns:
        min_expected_total_cost: float, optimal expected total cost
    """
    L = range(len(vehicle_costs))        # Terminals
    K = range(len(vehicle_costs[0]))     # Vehicle types
    S = range(len(demand_scenarios))     # Scenarios

    model = Model("WeeklyFleetSizing")
    model.setParam("OutputFlag", 0)

    # First-stage decision: how many vehicles of each type to deploy at each terminal
    z = model.addVars(L, K, lb=0, name="z")

    # Constraint: total vehicles of each type cannot exceed limit
    for k in K:
        model.addConstr(quicksum(z[i, k] for i in L) <= max_vehicles[k])

    # Second-stage variables per scenario
    y = model.addVars(L, L, K, S, lb=0, name="y")  # loaded moves
    y_empty = model.addVars(L, L, K, S, lb=0, name="y_empty")  # empty moves
    w = model.addVars(L, K, S, lb=0, name="imbalance")  # penalty variable

    for s in S:
        _, demand = demand_scenarios[s]
        for k in K:
            for i in L:
                # Vehicles leaving terminal i of type k must match z[i, k]
                model.addConstr(quicksum(y[i, j, k, s] + y_empty[i, j, k, s] for j in L) == z[i, k])
            for j in L:
                # Ending supply must match beginning (z[j, k]) ± imbalance
                model.addConstr(
                    quicksum(y[i, j, k, s] + y_empty[i, j, k, s] for i in L) + w[j, k, s] == z[j, k]
                )
            for i in L:
                for j in L:
                    # Demand constraint: cannot send more than demand allows
                    model.addConstr(y[i, j, k, s] >= demand[i][j][k])

    # Objective: deployment cost + expected transport cost + expected penalty
    deploy_cost = quicksum(vehicle_costs[i][k] * z[i, k] for i in L for k in K)

    expected_cost = quicksum(
        demand_scenarios[s][0] * (
            quicksum(
                move_costs_loaded[i][j][k] * y[i, j, k, s] +
                move_costs_empty[i][j][k] * y_empty[i, j, k, s]
                for i in L for j in L for k in K
            ) + quicksum(penalties[j][k] * w[j, k, s] for j in L for k in K)
        )
        for s in S
    )

    model.setObjective(deploy_cost + expected_cost, GRB.MINIMIZE)
    model.optimize()

    return model.ObjVal if model.Status == GRB.OPTIMAL else None