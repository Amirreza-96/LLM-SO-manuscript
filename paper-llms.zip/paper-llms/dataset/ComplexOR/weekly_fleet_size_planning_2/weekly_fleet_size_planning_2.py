from gurobipy import Model, GRB, quicksum

def weekly_fleet_size_planning_2(input_data):
    vehicle_costs = input_data["vehicle_costs"]
    max_vehicles = input_data["max_vehicles"]
    move_costs_loaded = input_data["move_costs_loaded"]
    move_costs_empty = input_data["move_costs_empty"]
    penalties = input_data["penalties"]
    demand_scenarios = input_data["demand_scenarios"]

    L = range(len(vehicle_costs))
    K = range(len(vehicle_costs[0]))
    S = range(len(demand_scenarios))

    m = Model("WeeklyFleetSizing_v2")
    m.setParam("OutputFlag", 0)

    z = m.addVars(L, K, vtype=GRB.INTEGER, lb=0, name="z")
    yL = m.addVars(L, L, K, S, vtype=GRB.INTEGER, lb=0, name="y_loaded")
    yE = m.addVars(L, L, K, S, vtype=GRB.INTEGER, lb=0, name="y_empty")
    end = m.addVars(L, K, S, vtype=GRB.INTEGER, lb=0, name="end")
    u = m.addVars(L, K, S, lb=0, name="surplus")
    v = m.addVars(L, K, S, lb=0, name="shortage")

    m.addConstrs(
        (quicksum(z[i, k] for i in L) <= max_vehicles[k] for k in K),
        name="fleet"
    )

    m.addConstrs(
        (
            yL[i, j, k, s] >= demand_scenarios[s]["demand"][i][j][k]
            for s in S for i in L for j in L for k in K if i != j
        ),
        name="demand"
    )

    m.addConstrs(
        (
            end[i, k, s]
            == z[i, k]
            + quicksum(yL[j, i, k, s] + yE[j, i, k, s] for j in L)
            - quicksum(yL[i, j, k, s] + yE[i, j, k, s] for j in L)
            for s in S for i in L for k in K
        ),
        name="enddef"
    )

    m.addConstrs(
        (end[i, k, s] - z[i, k] == u[i, k, s] - v[i, k, s] for s in S for i in L for k in K),
        name="mismatch"
    )

    m.addConstrs(
        (yL[i, i, k, s] == 0 for s in S for i in L for k in K),
        name="noSelfLoaded"
    )

    m.addConstrs(
        (yE[i, i, k, s] == 0 for s in S for i in L for k in K),
        name="noSelfEmpty"
    )

    m.setObjective(
        quicksum(vehicle_costs[i][k] * z[i, k] for i in L for k in K)
        + quicksum(
            demand_scenarios[s]["probability"] * (
                quicksum(
                    move_costs_loaded[i][j][k] * yL[i, j, k, s]
                    + move_costs_empty[i][j][k] * yE[i, j, k, s]
                    for i in L for j in L for k in K
                )
                + quicksum(
                    penalties[i][k] * (u[i, k, s] + v[i, k, s])
                    for i in L for k in K
                )
            )
            for s in S
        ),
        GRB.MINIMIZE
    )

    m.optimize()
    return m.ObjVal if m.Status == GRB.OPTIMAL else None
