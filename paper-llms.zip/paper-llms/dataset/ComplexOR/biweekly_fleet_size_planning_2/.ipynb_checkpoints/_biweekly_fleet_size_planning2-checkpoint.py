from gurobipy import Model, GRB, quicksum

def biweekly_fleet_sizing(availability_costs, move_costs_empty, move_costs_loaded,
                           penalties, demand_scenarios, first_week_capacity_limits):
    L = range(len(availability_costs))  # Terminals
    S = range(len(demand_scenarios))   # Scenarios

    model = Model("BiWeeklyFleetPlanning")
    model.setParam("OutputFlag", 0)

    # First-stage variables
    z = model.addVars(L, lb=0, name="z")  # vehicles deployed at terminal i
    x = model.addVars(L, L, lb=0, name="x")  # empty moves i -> j
    x_loaded = model.addVars(L, L, lb=0, name="x_loaded")  # loaded moves i -> j

    z_tilde = model.addVars(L, lb=0, name="z_tilde")  # week-2 starting supply at each terminal

    for i in L:
        model.addConstr(quicksum(x[i, j] + x_loaded[i, j] for j in L) == z[i])
    for j in L:
        model.addConstr(quicksum(x[i, j] + x_loaded[i, j] for i in L) == z_tilde[j])
    for i in L:
        for j in L:
            model.addConstr(x[i, j] + x_loaded[i, j] <= first_week_capacity_limits[i][j])

    # Second-stage variables per scenario
    y = model.addVars(L, L, S, lb=0, name="y")         # loaded vehicles in week 2
    y_empty = model.addVars(L, L, S, lb=0, name="y_empty")  # empty vehicles in week 2
    w = model.addVars(L, S, lb=0, name="imbalance")    # imbalance penalties at end of week 2

    for s in S:
        _, demand = demand_scenarios[s]
        # Week-2 flow balance: outflow = z_tilde
        for i in L:
            model.addConstr(quicksum(y[i, j, s] + y_empty[i, j, s] for j in L) == z_tilde[i])
        # End-of-week balance: inflow + unmet imbalance = original z
        for j in L:
            model.addConstr(quicksum(y[i, j, s] + y_empty[i, j, s] for i in L) + w[j, s] == z[j])
        # Demand satisfaction (can't exceed demand)
        for i in L:
            for j in L:
                model.addConstr(y[i, j, s] >= demand[i][j])

    # Objective
    deploy_cost = quicksum(availability_costs[i] * z[i] for i in L)
    week1_cost = quicksum(move_costs_empty[i][j] * x[i, j] + move_costs_loaded[i][j] * x_loaded[i, j]
                          for i in L for j in L)
    week2_expected_cost = quicksum(
        demand_scenarios[s][0] * (
            quicksum(move_costs_empty[i][j] * y_empty[i, j, s] +
                     move_costs_loaded[i][j] * y[i, j, s]
                     for i in L for j in L) +
            quicksum(penalties[j] * w[j, s] for j in L)
        )
        for s in S
    )

    model.setObjective(deploy_cost + week1_cost + week2_expected_cost, GRB.MINIMIZE)
    model.optimize()

    return model.ObjVal if model.Status == GRB.OPTIMAL else None
