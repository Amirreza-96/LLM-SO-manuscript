from gurobipy import Model, GRB, quicksum

def electricity_planning(input_data):
    c = input_data["capacity_costs"]
    a = input_data["resource_use"]
    r = input_data["resource_limits"]
    p = input_data["ship_costs"]
    revenue = input_data["revenue"]
    demand_scenarios = input_data["demand_scenarios"]

    P = range(len(c))
    R = range(len(r))
    C = range(len(revenue))
    S = range(len(demand_scenarios))

    model = Model("ElectricityPlanning_ProfitMax")
    model.setParam("OutputFlag", 0)

    x = model.addVars(P, lb=0.0, name="x")
    y = model.addVars(P, C, S, lb=0.0, name="y")

    model.addConstrs(
        (quicksum(a[i][k] * x[i] for i in P) <= r[k] for k in R),
        name="resource"
    )

    model.addConstrs(
        (quicksum(y[i, j, s] for j in C) <= x[i] for s in S for i in P),
        name="cap"
    )

    model.addConstrs(
        (quicksum(y[i, j, s] for i in P) <= demand_scenarios[s]["demand"][j] for s in S for j in C),
        name="demcap"
    )

    model.setObjective(
        quicksum(
            demand_scenarios[s]["probability"] * revenue[j] * y[i, j, s]
            for s in S for i in P for j in C
        )
        - quicksum(c[i] * x[i] for i in P)
        - quicksum(
            demand_scenarios[s]["probability"] * p[i][j] * y[i, j, s]
            for s in S for i in P for j in C
        ),
        GRB.MAXIMIZE
    )

    model.optimize()
    return model.ObjVal if model.Status == GRB.OPTIMAL else None
