from gurobipy import Model, GRB, quicksum

def solve_joint_chance_from_input(input_data):
    alpha = input_data["alpha"]
    demand_samples = input_data["demand_samples"]
    num_scenarios = input_data["num_scenarios"]

    model = Model("EmergencySupply")
    model.setParam("OutputFlag", 0)

    # Supply allocations to Region A and B
    x = model.addVars(2, lb=0, name="x")

    # Binary violation indicators
    z = model.addVars(num_scenarios, vtype=GRB.BINARY, name="z")
    M = 1e5

    for s in range(num_scenarios):
        dA, dB = demand_samples[s]
        model.addConstr(x[0] >= dA - M * z[s])
        model.addConstr(x[1] >= dB - M * z[s])

    # Allow only limited violations
    model.addConstr(quicksum(z[s] for s in range(num_scenarios)) <= int(alpha * num_scenarios))

    # Objective: minimize total allocated supply
    model.setObjective(x[0] + x[1], GRB.MINIMIZE)
    model.optimize()

    if model.Status == GRB.OPTIMAL:
        x_val = model.getAttr("x", x)
        return {
            "region_A_supply": round(x_val[0], 2),
            "region_B_supply": round(x_val[1], 2),
            "total_supply": round(model.ObjVal, 2)
        }
    else:
        return None
