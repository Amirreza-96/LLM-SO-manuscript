def biweekly_fleet_size_planning(input_data):
    """
    Args:
        input_data: dict with keys
            - availability_costs: list, cost of deploying a vehicle at each terminal (|L|)
            - move_costs_empty: 2D list, cost of moving empty vehicles between terminals (|L| x |L|)
            - move_costs_loaded: 2D list, cost of moving loaded vehicles between terminals (|L| x |L|)
            - penalties: list, penalty cost per unit end-of-horizon imbalance at each terminal (|L|)
            - demand_scenarios: list of tuples (probability, demand_matrix), where demand_matrix is a 2D list (|L| x |L|)
              of random week-2 demand from i to j
            - first_week_capacity_limits: 2D list, upper bounds for total vehicles (empty + loaded) from i to j in week 1 (|L| x |L|)
            - second_week_capacity_limits (optional): 2D list, upper bounds for total vehicles (empty + loaded) from i to j in week 2 (|L| x |L|)
              If omitted, assume it equals first_week_capacity_limits.
            - first_week_demand (optional): 2D list (|L| x |L|) of deterministic week-1 demand from i to j; if provided, require week-1 loaded flow
              to cover it.

        # All constraints must be added using model.addConstrs(...). Do not use model.addConstr(...) anywhere.
        # The objective must be defined in a single model.setObjective(...) call, with the full quicksum expression written directly inside it.
        # Do not precompute or store partial objective expressions outside of model.setObjective(...).

    Returns:
        min_expected_total_cost: float, the minimum expected total cost (deployment + week-1 cost + expected week-2 cost + expected imbalance penalties)
    """
    min_expected_total_cost = 0  # Placeholder for the result of the optimization
    return min_expected_total_cost
