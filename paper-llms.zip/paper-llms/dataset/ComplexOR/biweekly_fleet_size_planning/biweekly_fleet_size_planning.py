from gurobipy import Model, GRB, quicksum

def biweekly_fleet_size_planning(input_data):
    availability_costs = input_data["availability_costs"]
    move_costs_empty = input_data["move_costs_empty"]
    move_costs_loaded = input_data["move_costs_loaded"]
    penalties = input_data["penalties"]
    demand_scenarios = input_data["demand_scenarios"]
    cap1 = input_data["first_week_capacity_limits"]
    cap2 = input_data.get("second_week_capacity_limits", cap1)
    demand_week1 = input_data.get("first_week_demand", None)

    n = len(availability_costs)
    L = range(n)
    S = range(len(demand_scenarios))

    model = Model("BiWeeklyFleetPlanning")
    model.setParam("OutputFlag", 0)

    z = model.addVars(L, lb=0.0, vtype=GRB.INTEGER)
    x1_empty = model.addVars(L, L, lb=0.0, vtype=GRB.INTEGER)
    x1_load = model.addVars(L, L, lb=0.0, vtype=GRB.INTEGER)
    end1 = model.addVars(L, lb=0.0, vtype=GRB.INTEGER)
    x2_empty = model.addVars(L, L, S, lb=0.0, vtype=GRB.INTEGER)
    x2_load = model.addVars(L, L, S, lb=0.0, vtype=GRB.INTEGER)
    end2 = model.addVars(L, S, lb=0.0, vtype=GRB.INTEGER)
    w_plus = model.addVars(L, S, lb=0.0)
    w_minus = model.addVars(L, S, lb=0.0)

    model.addConstrs(
        x1_empty[i, j] + x1_load[i, j] <= cap1[i][j]
        for i in L for j in L
    )

    if demand_week1 is not None:
        model.addConstrs(
            x1_load[i, j] >= demand_week1[i][j]
            for i in L for j in L
        )

    model.addConstrs(
        quicksum(x1_empty[i, j] + x1_load[i, j] for j in L) <= z[i]
        for i in L
    )

    model.addConstrs(
        end1[i] == z[i]
        + quicksum(x1_empty[j, i] + x1_load[j, i] for j in L)
        - quicksum(x1_empty[i, j] + x1_load[i, j] for j in L)
        for i in L
    )

    model.addConstrs(
        x2_empty[i, j, s] + x2_load[i, j, s] <= cap2[i][j]
        for s in S for i in L for j in L
    )

    model.addConstrs(
        x2_load[i, j, s] >= demand_scenarios[s][1][i][j]
        for s in S for i in L for j in L
    )

    model.addConstrs(
        quicksum(x2_empty[i, j, s] + x2_load[i, j, s] for j in L) <= end1[i]
        for s in S for i in L
    )

    model.addConstrs(
        end2[i, s] == end1[i]
        + quicksum(x2_empty[j, i, s] + x2_load[j, i, s] for j in L)
        - quicksum(x2_empty[i, j, s] + x2_load[i, j, s] for j in L)
        for s in S for i in L
    )

    model.addConstrs(
        end2[i, s] - z[i] == w_plus[i, s] - w_minus[i, s]
        for s in S for i in L
    )

    model.setObjective(
        quicksum(availability_costs[i] * z[i] for i in L)
        + quicksum(
            move_costs_empty[i][j] * x1_empty[i, j] + move_costs_loaded[i][j] * x1_load[i, j]
            for i in L for j in L
        )
        + quicksum(
            demand_scenarios[s][0] * (
                quicksum(
                    move_costs_empty[i][j] * x2_empty[i, j, s] + move_costs_loaded[i][j] * x2_load[i, j, s]
                    for i in L for j in L
                )
                + quicksum(penalties[i] * (w_plus[i, s] + w_minus[i, s]) for i in L)
            )
            for s in S
        ),
        GRB.MINIMIZE
    )

    model.optimize()

    if model.Status == GRB.OPTIMAL:
        return model.ObjVal
    return None
