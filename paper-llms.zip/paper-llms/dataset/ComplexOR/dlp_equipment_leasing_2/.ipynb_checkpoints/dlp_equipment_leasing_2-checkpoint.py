from gurobipy import Model, GRB, quicksum

def solve_equipment_leasing(input_data):
    lease_costs = input_data["lease_costs"]
    usage_costs = input_data["usage_costs"]
    job_requirements = input_data["job_requirements"]
    machine_limits = input_data["machine_limits"]

    M = len(lease_costs)
    J = len(job_requirements)

    model = Model("EquipmentLeasing")
    model.setParam("OutputFlag", 0)

    x = model.addVars(M, lb=0, ub=machine_limits, vtype=GRB.INTEGER, name="lease")
    y = model.addVars(M, J, lb=0, name="assign")

    model.addConstrs(
        (quicksum(y[i, j] for i in range(M)) >= job_requirements[j] for j in range(J)),
        name="req"
    )

    model.addConstrs(
        (quicksum(y[i, j] for j in range(J)) <= x[i] for i in range(M)),
        name="lease_cap"
    )

    model.setObjective(
        quicksum(lease_costs[i] * x[i] for i in range(M))
        + quicksum(usage_costs[i][j] * y[i, j] for i in range(M) for j in range(J)),
        GRB.MINIMIZE
    )

    model.optimize()
    return round(model.ObjVal, 2) if model.Status == GRB.OPTIMAL else None
