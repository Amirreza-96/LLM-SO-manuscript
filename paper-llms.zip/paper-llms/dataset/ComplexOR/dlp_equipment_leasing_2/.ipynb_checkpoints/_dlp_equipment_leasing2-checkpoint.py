from gurobipy import Model, GRB, quicksum

def solve_equipment_leasing(input_data):
    lease_costs = input_data["lease_costs"]
    usage_costs = input_data["usage_costs"]
    job_requirements = input_data["job_requirements"]
    machine_limits = input_data["machine_limits"]

    M = len(lease_costs)   # Machine types
    J = len(job_requirements)  # Job sites

    model = Model("Deterministic2Stage")
    model.setParam("OutputFlag", 0)

    # First-stage: lease x[i] machines of type i
    x = model.addVars(M, lb=0, ub=machine_limits, vtype=GRB.CONTINUOUS, name="lease")

    # Second-stage: assign y[i,j] machines of type i to job j
    y = model.addVars(M, J, lb=0, name="assign")

    # Meet job requirements
    for j in range(J):
        model.addConstr(quicksum(y[i, j] for i in range(M)) >= job_requirements[j])

    # Assign only leased machines
    for i in range(M):
        model.addConstr(quicksum(y[i, j] for j in range(J)) <= x[i])

    # Objective: leasing cost + assignment cost
    lease_term = quicksum(lease_costs[i] * x[i] for i in range(M))
    assign_term = quicksum(usage_costs[i][j] * y[i, j] for i in range(M) for j in range(J))

    model.setObjective(lease_term + assign_term, GRB.MINIMIZE)
    model.optimize()

    return round(model.ObjVal, 2) if model.Status == GRB.OPTIMAL else None