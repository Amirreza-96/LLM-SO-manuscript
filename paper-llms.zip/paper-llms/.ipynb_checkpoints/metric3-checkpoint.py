import re
from sympy import sympify, simplify
from sympy.core.sympify import SympifyError
import ast
import astor
from typing import Dict, Tuple, List, Set
import matplotlib.pyplot as plt

def eval1(true_model, generated_model):
        def extract_var_blocks(code: str) -> Dict[str, str]:
            pattern = re.compile(r'(\w+)\s*=\s*\w+\.addVars\((.*?)\)', re.DOTALL)
            var_blocks = {}
            for match in pattern.finditer(code):
                var_name, args = match.groups()
                var_blocks[var_name] = args.replace('\n', '').strip()
            return var_blocks
        
        def extract_constraints(code: str) -> Set[str]:
            constraints = set()
            start_token = ".addConstr("
            i = 0
        
            while i < len(code):
                start = code.find(start_token, i)
                if start == -1:
                    break
        
                i = start + len(start_token)
                depth = 1
                expr = ''
                while i < len(code) and depth > 0:
                    char = code[i]
                    expr += char
                    if char == '(': depth += 1
                    elif char == ')': depth -= 1
                    i += 1
        
                arg = ''
                bracket_depth = {'(': 0, '[': 0, '{': 0}
                for c in expr:
                    arg += c
                    if c == '(':
                        bracket_depth['('] += 1
                    elif c == ')':
                        bracket_depth['('] -= 1
                    elif c == '[':
                        bracket_depth['['] += 1
                    elif c == ']':
                        bracket_depth['['] -= 1
                    elif c == '{':
                        bracket_depth['{'] += 1
                    elif c == '}':
                        bracket_depth['{'] -= 1
                    elif c == ',':
                        if all(v == 0 for v in bracket_depth.values()):
                            arg = arg[:-1]
                            break
        
                clean_expr = ' '.join(arg.strip().split())
                constraints.add(clean_expr)
        
            return constraints
        
        def extract_objective(code: str) -> str:
          
        
            def strip_sum_wrappers(expr: str) -> str:
               
                expr = expr.strip()
                while True:
                    match = re.match(r'(?:\w+\.)?(quicksum|sum)\s*\(', expr)
                    if not match:
                        break
        
                    start_idx = match.end()
                    depth = 1
                    i = start_idx
                    while i < len(expr) and depth > 0:
                        if expr[i] == '(':
                            depth += 1
                        elif expr[i] == ')':
                            depth -= 1
                        i += 1
        
                    if depth != 0:
                        break   
                    expr = expr[start_idx:i - 1].strip()
                return expr
        
           
            code_no_comments = re.sub(r'#.*', '', code)
        
          
            pattern = re.compile(r'\w+\.setObjective\(\s*(.+?)\s*,\s*GRB\.MINIMIZE\s*\)', re.DOTALL)
            match = pattern.search(code_no_comments)
            if not match:
                return ''
        
            expr = match.group(1).strip()
        
            
            if re.fullmatch(r'\w+', expr):
                assign_pattern = re.compile(rf'{re.escape(expr)}\s*=\s*(.+)')
                assign_match = assign_pattern.search(code_no_comments)
                if assign_match:
                    expr = assign_match.group(1).strip()
        
           
            expr = strip_sum_wrappers(expr)
        
            return expr



    
        # def extract_objective1(code: str) -> str:
        #     class ObjectiveExtractor(ast.NodeVisitor):
        #         def __init__(self):
        #             self.expr_node = None
        
        #         def visit_Call(self, node):
        #             if (isinstance(node.func, ast.Attribute) and
        #                 node.func.attr == 'setObjective' and
        #                 len(node.args) >= 2):
        #                 # Ensure the second argument is GRB.MINIMIZE
        #                 if (isinstance(node.args[1], ast.Attribute) and 
        #                     node.args[1].attr == 'MINIMIZE'):
        #                     self.expr_node = node.args[0]
        #             self.generic_visit(node)
        
        #     tree = ast.parse(code)
        #     extractor = ObjectiveExtractor()
        #     extractor.visit(tree)
        
        #     if extractor.expr_node is None:
        #         return ''
        
        #     # Convert AST back to source code
        #     import astor  # You may need to install astor with `pip install astor`
        #     expr_src = astor.to_source(extractor.expr_node).strip()
        
        #     # Optional: strip wrappers
        #     def strip_sum_wrappers(expr: str) -> str:
        #         while True:
        #             match = re.match(r'(?:\w+\.)?(quicksum|sum)\s*\((.*)\)$', expr, re.DOTALL)
        #             if not match:
        #                 break
        #             expr = match.group(2).strip()
        #         return expr
        
        #     return strip_sum_wrappers(expr_src)



    

        def score_match(true_args: str, gen_args: str) -> int:
            score = 0
            for keyword in ['lb', 'ub', 'vtype']:
                true_kw = re.search(rf'{keyword}\s*=\s*[^,\)]+', true_args)
                gen_kw = re.search(rf'{keyword}\s*=\s*[^,\)]+', gen_args)
                if true_kw and gen_kw and true_kw.group() == gen_kw.group():
                    score += 1
            return score
        
        def normalize_structure(expr: str, target_var: str) -> str:
            expr = expr.replace('\n', '').strip()
            tokens = re.findall(r'\b\w+\[[^\]]+\]|\b\w+\b', expr)
        
            replaced = {}
            for tok in tokens:
                if tok == target_var:
                    replaced[tok] = '__X__'
                elif tok not in replaced:
                    replaced[tok] = '__Y__'
        
            for orig, repl in replaced.items():
                expr = re.sub(rf'\b{re.escape(orig)}\b', repl, expr)
        
            return expr


    
        def are_equivalent(expr1_str, expr2_str):
            try:
                expr1 = simplify(sympify(expr1_str))
                expr2 = simplify(sympify(expr2_str))
                return expr1.equals(expr2)
            except SympifyError:
                return False




        
        def score_constraints(true_constraints: Set[str], gen_constraints: Set[str], true_var: str, gen_var: str) -> int:
            score = 0
            for t_line in true_constraints:
                if true_var not in t_line:
                    continue
                for g_line in gen_constraints:
                    if gen_var not in g_line:
                        continue
                    t_structure = normalize_structure(t_line, true_var)
                    g_structure = normalize_structure(g_line, gen_var)
                    if are_equivalent(t_structure,g_structure):
                        score +=2
                    if t_structure == g_structure:
                        score += 2
                    elif t_structure.replace(' ', '') == g_structure.replace(' ', ''):
                        score += 2
            return score
        
        def score_objective(true_obj: str, gen_obj: str, true_var: str, gen_var: str) -> int:
            score = 0
            if true_var in true_obj and gen_var in gen_obj:
                t_expr = normalize_structure(true_obj, true_var)
                g_expr = normalize_structure(gen_obj, gen_var)
                if t_expr == g_expr:
                    score += 2
                if are_equivalent(t_expr,g_expr):
                    score +=2
                elif t_expr.replace(' ', '') == g_expr.replace(' ', ''):
                    score += 1
            return score
        def count_exact_matches(exprs: List[str], var: str) -> int:
          
            pattern = re.compile(rf'(?<![\w.]){re.escape(var)}(\s*\[\s*[^]]+\s*\])?(?![\w])')
            return sum(len(pattern.findall(expr)) for expr in exprs)
        def score_usage_frequency(true_exprs: List[str], gen_exprs: List[str], true_var: str, gen_var: str) -> int:
            true_count = count_exact_matches(true_exprs, true_var)
            gen_count = count_exact_matches(gen_exprs, gen_var)
            return min(true_count, gen_count)
        
        def score_term_alignment(true_obj: str, gen_obj: str, true_var: str, gen_var: str) -> int:
            terms_true = re.findall(r'([\w\[\]]+\s*\*\s*' + re.escape(true_var) + r'\[[^\]]+\])', true_obj)
            terms_gen = re.findall(r'([\w\[\]]+\s*\*\s*' + re.escape(gen_var) + r'\[[^\]]+\])', gen_obj)
            return len(set(terms_true) & set(terms_gen)) * 2
        
        def align_generated_model(true_model: str, generated_model: str) -> Tuple[str, Dict[str, str], Dict[str, Dict[str, int]]]:
            true_vars = extract_var_blocks(true_model)
            gen_vars = extract_var_blocks(generated_model)
            true_constraints = extract_constraints(true_model)
            gen_constraints = extract_constraints(generated_model)
            true_objective = extract_objective(true_model)
            gen_objective = extract_objective(generated_model)
        
            all_scores = []
            for g_var, g_args in gen_vars.items():
                for t_var, t_args in true_vars.items():
                    base_score = score_match(t_args, g_args)
                    constraint_score = score_constraints(true_constraints, gen_constraints, t_var, g_var)
                    objective_score = score_objective(true_objective, gen_objective, t_var, g_var)
                    freq_score = score_usage_frequency(list(true_constraints) + [true_objective], list(gen_constraints) + [gen_objective], t_var, g_var)
                    term_score = score_term_alignment(true_objective, gen_objective, t_var, g_var)
                    total_score = base_score + constraint_score + objective_score + freq_score + term_score
        
                    all_scores.append((total_score, g_var, t_var, {
                        'var': base_score,
                        'constraints': constraint_score,
                        'objective': objective_score,
                        'frequency': freq_score,
                        'terms': term_score,
                        'total': total_score
                    }))
        
            
        
            
            all_scores.sort(key=lambda x: -x[0])
            mapping = {}
            scores = {}
            used_true_vars = set()
            used_gen_vars = set()
        
            for score, g_var, t_var, detail in all_scores:
                if g_var not in used_gen_vars and t_var not in used_true_vars:
                    mapping[g_var] = t_var
                    scores[g_var] = detail
                    used_gen_vars.add(g_var)
                    used_true_vars.add(t_var)
        
            aligned_code = generated_model
            for old, new in sorted(mapping.items(), key=lambda x: -len(x[0])):
                aligned_code = re.sub(rf'\b{old}\b', new, aligned_code)
        
            return aligned_code, mapping, scores
        def extract_var_blocks(code: str) -> Dict[str, str]:
            pattern = re.compile(r'(\w+)\s*=\s*\w+\.addVars\((.*?)\)', re.DOTALL)
            var_blocks = {}
            for match in pattern.finditer(code):
                var_name, args = match.groups()
                var_blocks[var_name] = args.replace('\n', '').strip()
            return var_blocks
        def strip_sum_wrappers(expr: str) -> str:
           
            expr = expr.strip()
        
            while True:
                
                match = re.match(r'(?:\w+\.)?(quicksum|sum)\s*\(', expr)
                if not match:
                    break
        
                start_idx = match.end()  
                depth = 1
                i = start_idx
        
                while i < len(expr) and depth > 0:
                    if expr[i] == '(':
                        depth += 1
                    elif expr[i] == ')':
                        depth -= 1
                    i += 1
        
                if depth != 0:
                    break  
        
                
                expr = expr[start_idx:i - 1].strip()
        
            return expr
        
        def extract_constraints(code: str) -> Set[str]:
          
            constraints = set()
            start_token = ".addConstr("
            i = 0
        
            while i < len(code):
                start = code.find(start_token, i)
                if start == -1:
                    break  
        
                i = start + len(start_token)
                depth = 1
                expr = ''
                while i < len(code) and depth > 0:
                    char = code[i]
                    expr += char
                    if char == '(':
                        depth += 1
                    elif char == ')':
                        depth -= 1
                    i += 1
        
               
                arg = ''
                bracket_depth = {'(': 0, '[': 0, '{': 0}
                for j, c in enumerate(expr):
                    arg += c
                    if c == '(':
                        bracket_depth['('] += 1
                    elif c == ')':
                        bracket_depth['('] -= 1
                    elif c == '[':
                        bracket_depth['['] += 1
                    elif c == ']':
                        bracket_depth['['] -= 1
                    elif c == '{':
                        bracket_depth['{'] += 1
                    elif c == '}':
                        bracket_depth['{'] -= 1
                    elif c == ',':
                        if all(v == 0 for v in bracket_depth.values()):
                            arg = arg[:-1]  
                            break
        
                clean_expr = ' '.join(arg.strip().split())
                clean_expr = strip_sum_wrappers(clean_expr)
                constraints.add(clean_expr)
        
            return constraints
        
        
        
        def extract_objective(code: str) -> str:
          
        
            def strip_sum_wrappers(expr: str) -> str:
               
                expr = expr.strip()
                while True:
                    match = re.match(r'(?:\w+\.)?(quicksum|sum)\s*\(', expr)
                    if not match:
                        break
        
                    start_idx = match.end()
                    depth = 1
                    i = start_idx
                    while i < len(expr) and depth > 0:
                        if expr[i] == '(':
                            depth += 1
                        elif expr[i] == ')':
                            depth -= 1
                        i += 1
        
                    if depth != 0:
                        break   
                    expr = expr[start_idx:i - 1].strip()
                return expr
        
           
            code_no_comments = re.sub(r'#.*', '', code)
        
            
            pattern = re.compile(r'\w+\.setObjective\(\s*(.+?)\s*,\s*GRB\.MINIMIZE\s*\)', re.DOTALL)
            match = pattern.search(code_no_comments)
            if not match:
                return ''
        
            expr = match.group(1).strip()
        
           
            if re.fullmatch(r'\w+', expr):
                assign_pattern = re.compile(rf'{re.escape(expr)}\s*=\s*(.+)')
                assign_match = assign_pattern.search(code_no_comments)
                if assign_match:
                    expr = assign_match.group(1).strip()
        
            
            expr = strip_sum_wrappers(expr)
        
            return expr
        
        def separate_model_components(code: str) -> Tuple[Set[str], Set[str], Set[str]]:
            vars_dict = extract_var_blocks(code)
            variables = set(vars_dict.keys())
            constraints = extract_constraints(code)
            objective = extract_objective(code)
            return variables, constraints, objective
        
        def compare_models(true_model: str, generated_model: str) -> Tuple[Dict[str, Set[str]], Dict[str, Set[str]]]:
            true_vars, true_constraints, true_objective = separate_model_components(true_model)
            gen_vars, gen_constraints, gen_objective = separate_model_components(generated_model)
        
            true_components = {
                'variables': true_vars,
                'constraints': true_constraints,
                'objective': {true_objective}
            }
        
            generated_components = {
                'variables': gen_vars,
                'constraints': gen_constraints,
                'objective': {gen_objective}
            }
        
            return true_components, generated_components
        def normalize_indexing(expr: str) -> str:
           
            
            expr = re.sub(r'\[[^\]]+\]', '[idx]', expr)
            
            expr = re.sub(r'for\s+\w+\s+in\s+range\([^\)]+\)', 'for idx in range(RANGE)', expr)
            return expr
        
        def calculate_mismatches(
                    true_components: Dict[str, Set[str]],
                    generated_components: Dict[str, Set[str]],
                    var_mapping: Dict[str, str]  # gen_var -> true_var
                    ) -> Tuple[float, float, float, float, float]:
            

            categories = ['variables', 'constraints', 'objective']
            total_true = 0
            total_generated = 0
            total_matches = 0
            total_missing_from_generated = 0
            total_extra_in_generated = 0
            percent_matched_variables = 0.0
            percent_matched_constraints = 0.0
            percent_matched_objective = 0.0
        
            for category in categories:
                true_set = true_components[category]
                gen_set = generated_components[category]
        
                matched = set()
                used_gen = set()
        
                for true_expr in true_set:
                    matched_this = False
                    for gen_expr in gen_set:
                        if gen_expr in used_gen:
                            continue
        
                        # Exact match via indexing normalization
                        if normalize_indexing(true_expr) == normalize_indexing(gen_expr):
                            matched_this = True
        
                        # If not, try structural + algebraic matching (for constraints/objective)
                        elif category in {'constraints', 'objective'}:
                            for gen_var, true_var in var_mapping.items():
                                norm_true = normalize_structure(true_expr, true_var)
                                norm_gen = normalize_structure(gen_expr, gen_var)
                                if norm_true == norm_gen:
                                    matched_this = True
                                    break
                                elif are_equivalent(norm_true, norm_gen):
                                    matched_this = True
                                    break
        
                        if matched_this:
                            matched.add(true_expr)
                            used_gen.add(gen_expr)
                            break
        
                only_in_true = true_set - matched
                only_in_gen = gen_set - used_gen
        
                true_count = len(true_set)
                gen_count = len(gen_set)
                match_count = len(matched)
        
                percent_matched = (match_count / true_count * 100) if true_count > 0 else 0
        
                if category == 'variables':
                    percent_matched_variables = percent_matched
                elif category == 'constraints':
                    percent_matched_constraints = percent_matched
                elif category == 'objective':
                    percent_matched_objective = percent_matched
        
                total_true += true_count
                total_generated += gen_count
                total_matches += match_count
                total_missing_from_generated += len(only_in_true)
                total_extra_in_generated += len(only_in_gen)

            percent_matched_total = (total_matches / total_true * 100) if total_true > 0 else 0.0
            percent_extra_in_generated = (total_extra_in_generated / total_generated * 100) if total_generated > 0 else 0.0

            return (
            percent_matched_total,
            percent_extra_in_generated,
            percent_matched_variables,
            percent_matched_constraints,
            percent_matched_objective
            )

        aligned_code, mapping , scores= align_generated_model(true_model, generated_model)
        print("Mapping:", mapping)
        print("scores",scores)
        print("Aligned Generated Code:\n", aligned_code)
        generated_model = aligned_code
        comparison = compare_models(true_model, generated_model)
       
        calculate_mismatches(comparison[0],comparison[1],mapping)
        return(calculate_mismatches(comparison[0],comparison[1],mapping))
        