from gurobipy import Model, GRB, quicksum

def solve_individual_chance_from_input(input_data):
    alpha = input_data["alpha"]
    demand_samples = input_data["demand_samples"]
    num_scenarios = len(demand_samples)

    model = Model("IndividualChance")
    model.setParam("OutputFlag", 0)

    x = model.addVars(2, lb=0, name="x")  # Supplies for region A and B
    z = model.addVars(2, num_scenarios, vtype=GRB.BINARY, name="z")  # Violation indicators

    M = 1e4
    for s in range(num_scenarios):
        d1, d2 = demand_samples[s]
        model.addConstr(x[0] >= d1 - M * z[0, s])  # Region A
        model.addConstr(x[1] >= d2 - M * z[1, s])  # Region B

    for r in [0, 1]:  # Enforce individual constraint limits
        model.addConstr(quicksum(z[r, s] for s in range(num_scenarios)) <= int(alpha * num_scenarios))

    model.setObjective(x[0] + x[1], GRB.MINIMIZE)
    model.optimize()

    if model.Status == GRB.OPTIMAL:
        return round(model.ObjVal, 2)
    else:
        return None
