from gurobipy import Model, GRB, quicksum
import math

def solve_joint_chance_from_input(input_data):
    alpha = float(input_data["alpha"])
    demand_samples = input_data["demand_samples"]
    N = len(demand_samples)

    model = Model("EmergencySupply")
    model.setParam("OutputFlag", 0)

    x = model.addVars(2, lb=0.0, name="x")
    z = model.addVars(N, vtype=GRB.BINARY, name="z")

    M_A = max(d[0] for d in demand_samples)
    M_B = max(d[1] for d in demand_samples)

    model.addConstrs(
        (x[0] >= demand_samples[s][0] - M_A * z[s] for s in range(N)),
        name="A"
    )
    model.addConstrs(
        (x[1] >= demand_samples[s][1] - M_B * z[s] for s in range(N)),
        name="B"
    )

    allowed = math.floor(alpha * N)
    model.addConstrs(
        (quicksum(z[s] for s in range(N)) <= allowed for _ in range(1)),
        name="joint_chance"
    )

    model.setObjective(x[0] + x[1], GRB.MINIMIZE)
    model.optimize()

    return round(model.ObjVal, 2) if model.Status == GRB.OPTIMAL else None
