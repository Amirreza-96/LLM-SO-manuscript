from gurobipy import Model, GRB, quicksum
import math

def indi_cold_storage(input_data):
    alpha = float(input_data["alpha"])
    demand_samples = input_data["demand_samples"]
    N = len(demand_samples)

    model = Model("ColdStoragePlanning")
    model.setParam("OutputFlag", 0)

    x = model.addVars(2, lb=0.0, name="x")
    z = model.addVars(2, N, vtype=GRB.BINARY, name="z")

    max_east = max(s[0] for s in demand_samples)
    max_west = max(s[1] for s in demand_samples)
    M0, M1 = max_east, max_west

    model.addConstrs(
        (x[0] >= demand_samples[s][0] - M0 * z[0, s] for s in range(N)),
        name="east"
    )
    model.addConstrs(
        (x[1] >= demand_samples[s][1] - M1 * z[1, s] for s in range(N)),
        name="west"
    )

    allowed = math.floor(alpha * N)
    model.addConstrs(
        (quicksum(z[r, s] for s in range(N)) <= allowed for r in range(2)),
        name="chance"
    )

    model.setObjective(x[0] + x[1], GRB.MINIMIZE)
    model.optimize()

    return round(model.ObjVal, 2) if model.Status == GRB.OPTIMAL else None
