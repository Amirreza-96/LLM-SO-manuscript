from gurobipy import Model, GRB, quicksum

def solve_individual_chance_from_input(input_data):
    alpha = input_data["alpha"]
    demand_samples = input_data["demand_samples"]
    num_scenarios = len(demand_samples)

    model = Model("ColdStoragePlanning")
    model.setParam("OutputFlag", 0)

    x = model.addVars(2, lb=0, name="x")  # x[0] = east capacity, x[1] = west capacity
    z = model.addVars(2, num_scenarios, vtype=GRB.BINARY, name="z")
    M = 1e4

    for s in range(num_scenarios):
        east, west = demand_samples[s]
        model.addConstr(x[0] >= east - M * z[0, s])
        model.addConstr(x[1] >= west - M * z[1, s])

    for r in [0, 1]:  # Individual chance constraints
        model.addConstr(quicksum(z[r, s] for s in range(num_scenarios)) <= int(alpha * num_scenarios))

    model.setObjective(x[0] + x[1], GRB.MINIMIZE)
    model.optimize()

    if model.Status == GRB.OPTIMAL:
        return round(model.ObjVal, 2)
    else:
        return None
