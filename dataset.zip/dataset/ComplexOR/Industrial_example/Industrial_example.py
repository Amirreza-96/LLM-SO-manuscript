from gurobipy import Model, GRB, quicksum

def Industrial_example(P, S, C, K, A, c, scenarios, M):
    P = list(P)
    S = list(S)
    C = list(C)
    K = list(K)
    A = [tuple(e) for e in A]
    W = range(len(scenarios))

    P_set = set(P)
    S_set = set(S)
    C_set = set(C)

    inP = {j: [a for a, (i, jj) in enumerate(A) if jj == j] for j in P}
    outP = {j: [a for a, (ii, l) in enumerate(A) if ii == j] for j in P}
    inC = {j: [a for a, (i, jj) in enumerate(A) if jj == j] for j in C}

    model = Model("SMILP2_Extensive")
    model.setParam("OutputFlag", 0)

    y = model.addVars(range(len(P)), vtype=GRB.BINARY, name="y")

    x = model.addVars(((a, k, w) for a in range(len(A)) for k in range(len(K)) for w in W), lb=0.0, name="x")
    z = model.addVars(((j, k, w) for j in range(len(C)) for k in range(len(K)) for w in W), lb=0.0, name="z")
    u = model.addVars(((i, k, w) for i in range(len(S)) for k in range(len(K)) for w in W), lb=0.0, name="u")

    P_index = {p: i for i, p in enumerate(P)}
    S_index = {p: i for i, p in enumerate(S)}
    C_index = {cname: j for j, cname in enumerate(C)}

    model.setObjective(
        quicksum(c[i] * y[i] for i in range(len(P))) +
        quicksum(
            scenarios[w]["probability"] * (
                quicksum(
                    scenarios[w]["q"][a][k] * x[a, k, w]
                    for a in range(len(A)) for k in range(len(K))
                ) +
                quicksum(
                    scenarios[w]["h"][j][k] * z[j, k, w]
                    for j in range(len(C)) for k in range(len(K))
                )
            )
            for w in W
        ),
        GRB.MINIMIZE
    )

    for w in W:
        model.addConstrs(
            (
                quicksum(x[a, k, w] for a in inP[p]) - quicksum(x[a, k, w] for a in outP[p]) == 0
                for p in P if p not in S_set for k in range(len(K))
            ),
            name=f"flow_nonS_w{w}"
        )

        model.addConstrs(
            (
                quicksum(x[a, k, w] for a in inP[p]) + u[S_index[p], k, w] - quicksum(x[a, k, w] for a in outP[p]) == 0
                for p in S for k in range(len(K))
            ),
            name=f"flow_S_w{w}"
        )

        model.addConstrs(
            (
                u[i, k, w] <= scenarios[w]["s"][i][k] * y[P_index[S[i]]]
                for i in range(len(S)) for k in range(len(K))
            ),
            name=f"inj_supply_w{w}"
        )

        model.addConstrs(
            (
                quicksum(x[a, k, w] for a in inC[C[j]]) + z[j, k, w] >= scenarios[w]["d"][j][k]
                for j in range(len(C)) for k in range(len(K))
            ),
            name=f"demand_w{w}"
        )

        model.addConstrs(
            (
                quicksum(x[a, k, w] for a in outP[p]) <= M * y[P_index[p]]
                for p in P for k in range(len(K))
            ),
            name=f"no_out_unopened_w{w}"
        )

        model.addConstrs(
            (
                quicksum(x[a, k, w] for a in inP[p]) <= M * y[P_index[p]]
                for p in P for k in range(len(K))
            ),
            name=f"no_in_unopened_w{w}"
        )

    model.optimize()

    if model.Status == GRB.OPTIMAL:
        return float(model.ObjVal)
    return None
