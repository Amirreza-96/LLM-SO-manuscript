from gurobipy import Model, GRB, quicksum

def solve_production_distribution(input_data):
    prod_costs = input_data["production_costs"]
    dist_costs = input_data["distribution_costs"]
    dist_targets = input_data["distribution_targets"]
    resource_usage = input_data["resource_usage"]
    resource_limits = input_data["resource_limits"]

    P = range(len(prod_costs))      # Products
    W = range(len(dist_targets))    # Warehouses
    R = range(len(resource_limits)) # Resources

    model = Model("ProductionDistribution")
    model.setParam("OutputFlag", 0)

    # First-stage: production quantities
    x = model.addVars(P, lb=0, name="produce")

    # Second-stage: shipments to warehouses
    y = model.addVars(P, W, lb=0, name="ship")

    # Resource constraints
    for r in R:
        model.addConstr(quicksum(resource_usage[p][r] * x[p] for p in P) <= resource_limits[r])

    # Fulfill warehouse demand
    for w in W:
        model.addConstr(quicksum(y[p, w] for p in P) >= dist_targets[w])

    # Can't ship more than is produced
    for p in P:
        model.addConstr(quicksum(y[p, w] for w in W) <= x[p])

    # Objective: production + distribution cost
    total_cost = (
        quicksum(prod_costs[p] * x[p] for p in P) +
        quicksum(dist_costs[p][w] * y[p, w] for p in P for w in W)
    )

    model.setObjective(total_cost, GRB.MINIMIZE)
    model.optimize()

    return round(model.ObjVal, 2) if model.Status == GRB.OPTIMAL else None
