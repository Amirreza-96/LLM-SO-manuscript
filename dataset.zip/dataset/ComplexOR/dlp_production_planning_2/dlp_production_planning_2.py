from gurobipy import Model, GRB, quicksum

def dlp_production_planning_2(input_data):
    prod_costs = input_data["production_costs"]
    dist_costs = input_data["distribution_costs"]
    dist_targets = input_data["distribution_targets"]
    resource_usage = input_data["resource_usage"]
    resource_limits = input_data["resource_limits"]

    P = range(len(prod_costs))
    W = range(len(dist_targets[0]))
    R = range(len(resource_limits))

    model = Model("ProductionDistribution")
    model.setParam("OutputFlag", 0)

    x = model.addVars(P, lb=0.0, name="produce")
    y = model.addVars(P, W, lb=0.0, name="ship")

    model.addConstrs(
        (quicksum(resource_usage[r][p] * x[p] for p in P) <= resource_limits[r] for r in R),
        name="res"
    )

    model.addConstrs(
        (y[p, w] == dist_targets[p][w] for p in P for w in W),
        name="target"
    )

    model.addConstrs(
        (quicksum(y[p, w] for w in W) <= x[p] for p in P),
        name="supply"
    )

    model.setObjective(
        quicksum(prod_costs[p] * x[p] for p in P)
        + quicksum(dist_costs[p][w] * y[p, w] for p in P for w in W),
        GRB.MINIMIZE
    )

    model.optimize()
    return round(model.ObjVal, 2) if model.Status == GRB.OPTIMAL else None
